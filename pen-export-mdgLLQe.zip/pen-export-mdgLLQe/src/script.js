// script.js

// Sample data for demonstration
const featuredRecipes = [
    { title: "Spaghetti Carbonara", image: "spaghetti-carbonara.jpg" },
    { title: "Mango Chicken Curry", image: "mango-chicken-curry.jpg" },
    { title: "Quinoa Salad", image: "quinoa-salad.jpg" }
];

// Function to display featured recipes
function displayFeaturedRecipes() {
    const featuredRecipesSection = document.getElementById("featured-recipes");

    featuredRecipes.forEach(recipe => {
        const recipeCard = document.createElement("div");
        recipeCard.classList.add("recipe-card");
        recipeCard.innerHTML = `
            <img src="images/${recipe.image}" alt="${recipe.title}">
            <h3>${recipe.title}</h3>
        `;
        featuredRecipesSection.appendChild(recipeCard);
    });
}

// Call the function to display featured recipes
displayFeaturedRecipes();
// script.js

// Sample data for demonstration
const mealPlans = [
    { day: "Monday", recipe: "Spaghetti Carbonara" },
    { day: "Tuesday", recipe: "Mango Chicken Curry" },
    { day: "Wednesday", recipe: "Quinoa Salad" }
];

// Function to display meal plans
function displayMealPlans() {
    const mealPlanningSection = document.getElementById("meal-planning");

    mealPlans.forEach(plan => {
        const planItem = document.createElement("div");
        planItem.classList.add("plan-item");
        planItem.innerHTML = `
            <h3>${plan.day}</h3>
            <p>${plan.recipe}</p>
        `;
        mealPlanningSection.appendChild(planItem);
    });
}

// Call the function to display meal plans
displayMealPlans();

// Sample data for demonstration
const groceryItems = [
    { name: "Spaghetti", quantity: 1 },
    { name: "Bacon", quantity: 200, unit: "g" },
    { name: "Eggs", quantity: 6 }
];

// Function to display grocery list
function displayGroceryList() {
    const groceryListSection = document.getElementById("grocery-list");

    groceryItems.forEach(item => {
        const listItem = document.createElement("div");
        listItem.classList.add("grocery-item");
        listItem.innerHTML = `
            <p>${item.quantity}${item.unit ? " " + item.unit : ""} ${item.name}</p>
        `;
        groceryListSection.appendChild(listItem);
    });
}

// Call the function to display grocery list
displayGroceryList();
// script.js

// Sample data for demonstration
const communityPosts = [
    { username: "CookingEnthusiast", title: "Delicious Spaghetti Carbonara Recipe", content: "I just made the most amazing Spaghetti Carbonara! Check out the recipe..." },
    { username: "HealthyEater123", title: "Quinoa Salad - Perfect for Summer!", content: "Looking for a refreshing salad recipe? Try this Quinoa Salad recipe..." },
    { username: "GlobalChef", title: "Authentic Mango Chicken Curry", content: "Learn how to make an authentic Mango Chicken Curry with this easy recipe..." }
];

// Function to display community posts
function displayCommunityPosts() {
    const communitySection = document.getElementById("community");

    communityPosts.forEach(post => {
        const postItem = document.createElement("div");
        postItem.classList.add("community-post");
        postItem.innerHTML = `
            <h3>${post.title}</h3>
            <p>${post.content}</p>
            <span>Posted by ${post.username}</span>
        `;
        communitySection.appendChild(postItem);
    });
}

// Call the function to display community posts
displayCommunityPosts();
// script.js

// Function to handle form submission
function handleFormSubmit(event) {
    event.preventDefault();

    // Get form values
    const username = document.getElementById("username").value;
    const title = document.getElementById("title").value;
    const content = document.getElementById("content").value;

    // Create new post object
    const newPost = {
        username: username,
        title: title,
        content: content
    };

    // Add new post to the beginning of the community posts array
    communityPosts.unshift(newPost);

    // Clear form fields
    document.getElementById("new-post-form").reset();

    // Update community posts display
    displayCommunityPosts();
}

// Add event listener to form submission
const form = document.getElementById("new-post-form");
form.addEventListener("submit", handleFormSubmit);
// script.js

// Function to display community posts
function displayCommunityPosts() {
    const communitySection = document.getElementById("community");
    const communityPostsContainer = document.getElementById("community-posts");

    // Clear existing posts
    communityPostsContainer.innerHTML = "";

    // Render new posts
    communityPosts.forEach(post => {
        const postItem = document.createElement("div");
        postItem.classList.add("community-post");
        postItem.innerHTML = `
            <h3>${post.title}</h3>
            <p>${post.content}</p>
            <span>Posted by ${post.username}</span>
        `;
        communityPostsContainer.appendChild(postItem);
    });
}
// Function to handle form submission
function handleFormSubmit(event) {
    event.preventDefault();

    // Get form values
    const username = document.getElementById("username").value.trim();
    const title = document.getElementById("title").value.trim();
    const content = document.getElementById("content").value.trim();

    // Validate form fields
    if (username === "" || title === "" || content === "") {
        alert("Please fill out all fields.");
        return;
    }

    // Create new post object
    const newPost = {
        username: username,
        title: title,
        content: content
    };

    // Add new post to the beginning of the community posts array
    communityPosts.unshift(newPost);

    // Clear form fields
    document.getElementById("new-post-form").reset();

    // Update community posts display
    displayCommunityPosts();
}
// Function to display community posts
function displayCommunityPosts() {
    const communitySection = document.getElementById("community");
    const communityPostsContainer = document.getElementById("community-posts");

    // Clear existing posts
    communityPostsContainer.innerHTML = "";

    // Render new posts
    communityPosts.forEach((post, index) => {
        const postItem = document.createElement("div");
        postItem.classList.add("community-post");
        postItem.innerHTML = `
            <h3>${post.title}</h3>
            <p>${post.content}</p>
            <span>Posted by ${post.username}</span>
            <div class="post-actions">
                <button class="edit-post" data-index="${index}">Edit</button>
                <button class="delete-post" data-index="${index}">Delete</button>
            </div>
        `;
        communityPostsContainer.appendChild(postItem);
    });
}
// Function to handle edit post action
function handleEditPost(event) {
    const index = event.target.dataset.index;
    const post = communityPosts[index];

    // Assuming you have some UI for editing a post, e.g., a modal
    // Here, you would populate the UI with the post data for editing
    console.log("Editing post:", post);
}

// Function to handle delete post action
function handleDeletePost(event) {
    const index = event.target.dataset.index;
    
    // Remove the post from the communityPosts array
    communityPosts.splice(index, 1);

    // Update community posts display
    displayCommunityPosts();
}

// Add event listeners for edit and delete actions
document.addEventListener("click", function(event) {
    if (event.target.classList.contains("edit-post")) {
        handleEditPost(event);
    } else if (event.target.classList.contains("delete-post")) {
        handleDeletePost(event);
    }
});
// script.js

// Function to open the edit post modal with pre-filled data
function openEditModal(event) {
    const index = event.target.dataset.index;
    const post = communityPosts[index];

    // Populate the form fields with post data
    document.getElementById("edit-title").value = post.title;
    document.getElementById("edit-content").value = post.content;

    // Display the modal
    const modal = document.getElementById("edit-post-modal");
    modal.style.display = "block";

    // Save the index of the post being edited in a data attribute of the modal
    modal.dataset.index = index;
}

// Event listener for opening the edit post modal
document.addEventListener("click", function(event) {
    if (event.target.classList.contains("edit-post")) {
        openEditModal(event);
    }
});

// Function to handle form submission for editing a post
function handleEditPostFormSubmit(event) {
    event.preventDefault();

    // Get form values
    const index = document.getElementById("edit-post-modal").dataset.index;
    const title = document.getElementById("edit-title").value.trim();
    const content = document.getElementById("edit-content").value.trim();

    // Validate form fields
    if (title === "" || content === "") {
        alert("Please fill out all fields.");
        return;
    }

    // Update the post in the communityPosts array
    communityPosts[index].title = title;
    communityPosts[index].content = content;

    // Close the modal
    document.getElementById("edit-post-modal").style.display = "none";

    // Update community posts display
    displayCommunityPosts();
}

// Event listener for form submission in the edit post modal
document.getElementById("edit-post-form").addEventListener("submit", handleEditPostFormSubmit);

// Close the modal when the user clicks the close button or outside the modal
document.getElementById("edit-post-modal").querySelector(".close").addEventListener("click", function() {
    document.getElementById("edit-post-modal").style.display = "none";
});
window.addEventListener("click", function(event) {
    const modal = document.getElementById("edit-post-modal");
    if (event.target === modal) {
        modal.style.display = "none";
    }
});
// script.js

// Function to handle delete post action
function handleDeletePost(event) {
    const index = event.target.dataset.index;

    // Display confirmation dialog
    const confirmation = confirm("Are you sure you want to delete this post?");
    if (confirmation) {
        // Remove the post from the communityPosts array
        communityPosts.splice(index, 1);

        // Update community posts display
        displayCommunityPosts();
    }
}

// Event listener for delete post action
document.addEventListener("click", function(event) {
    if (event.target.classList.contains("delete-post")) {
        handleDeletePost(event);
    }
});
